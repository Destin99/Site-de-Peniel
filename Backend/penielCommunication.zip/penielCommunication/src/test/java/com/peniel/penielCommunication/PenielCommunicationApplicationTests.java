package com.peniel.penielCommunication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PenielCommunicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
