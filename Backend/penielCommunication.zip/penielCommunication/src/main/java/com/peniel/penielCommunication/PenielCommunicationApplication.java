package com.peniel.penielCommunication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenielCommunicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenielCommunicationApplication.class, args);
	}

}
